﻿using Microsoft.AspNetCore.Mvc;
using WebChamado.Models;

namespace WebChamado.Controllers
{
    public class ChamadoController : Controller
    {
        [HttpGet]
        public IActionResult AbrirChamado()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AbrirChamado(AbrirChamadoModel chamado)
        {
            if (ModelState.IsValid)
            {
                // Por enquanto só simula o envio
                // Aqui você pode até exibir no console pra teste
                Console.WriteLine($"Chamado criado: {chamado.Titulo} - {chamado.Descricao} - {chamado.Categoria}");

                // Redireciona para a página de confirmação
                return RedirectToAction("TicketEnviado");
            }

            // Se houver erro de validação, retorna para o formulário
            return View(chamado);
        }

        public IActionResult TicketEnviado()
        {
            return View();
        }
    }
}

