package com.pim.pimsuporte;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

// Importações para a API (Retrofit e seus modelos)
import models.Chamado;
import API.API; // Mantenho API (uppercase) conforme você usou no código
import API.retrofitclient; // Mantenho retrofitclient (lowercase) conforme você usou no código

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Tela_Inicial extends AppCompatActivity {

    private static final int ID_USUARIO_LOGADO = 1;

    // Novos campos para a lista de tickets
    private RecyclerView recyclerView;
    private TicketAdapter adapter;
    private API apiService; // Interface para a chamada da API



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_inicial);

        // Configuração padrão de Insets (mantenha)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        // 1. Inicializa o RecyclerView
        // (Certifique-se que o ID 'recyclerViewTickets' está no seu activity_tela_inicial.xml)
        recyclerView = findViewById(R.id.recyclerViewTickets);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 2. Inicializa o serviço da API
        apiService = retrofitclient.getApiService();

        // 3. Inicia o carregamento dos tickets
        carregarTickets();

    }


    private void carregarTickets() {
        // Executa a chamada de API (definida no ApiService)
        Call<List<Chamado>> call = apiService.buscarTodosTickets();

        call.enqueue(new Callback<List<Chamado>>() {
            @Override
            public void onResponse(Call<List<Chamado>> call, Response<List<Chamado>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Chamado> listaDeTickets = response.body();

                    List<Chamado> meusTickets = new ArrayList<>();
                    for (Chamado ticket : listaDeTickets) {
                        if (ticket.getFkUsuario() == ID_USUARIO_LOGADO) {
                            meusTickets.add(ticket);
                        }
                    }

                    // Verifica se o usuário tem tickets
                    if (meusTickets.isEmpty()) {
                        Toast.makeText(Tela_Inicial.this,
                                "Você ainda não tem tickets abertos.",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(Tela_Inicial.this,
                                meusTickets.size() + " ticket(s) encontrado(s)",
                                Toast.LENGTH_SHORT).show();
                    }

                    // Conecta os dados ao Adapter e exibe no RecyclerView
                    adapter = new TicketAdapter(listaDeTickets);
                    recyclerView.setAdapter(adapter);

                } else {
                    // Trata erros HTTP (ex: 404, 500)
                    Toast.makeText(Tela_Inicial.this, "Erro ao carregar tickets. Código: " + response.code(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Chamado>> call, Throwable t) {
                // Trata erros de rede
                Toast.makeText(Tela_Inicial.this, "Falha de Conexão. Verifique a internet.", Toast.LENGTH_LONG).show();
                t.printStackTrace();
            }
        });
    }
}