﻿using System;
using System.ComponentModel.DataAnnotations;


namespace WebChamado.Models
{
    public class AbrirChamadoModel
    {
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string Categoria { get; set; }
    }
}

