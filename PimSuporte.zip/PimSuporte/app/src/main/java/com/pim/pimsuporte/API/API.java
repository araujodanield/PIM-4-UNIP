package com.pim.pimsuporte.API;

import com.pim.pimsuporte.models.Chamado;
import com.pim.pimsuporte.models.ChamadosUpdate;
import com.pim.pimsuporte.models.Categoria;
import com.pim.pimsuporte.models.Status;
import com.pim.pimsuporte.models.Usuario;
import com.pim.pimsuporte.models.RespostaIA;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface API {

    // ======================================
    // CHAMADOS
    // ======================================

    // GET /api/chamados - Listar todos os chamados
    @GET("api/chamados")
    Call<List<Chamado>> listarTodosChamados();

    // GET /api/chamados/{id} - Buscar chamado por ID
    @GET("api/chamados/{id}")
    Call<Chamado> buscarChamadoPorId(@Path("id") int idChamado);

    // PUT /api/chamados/{id} - Atualizar chamado
    @PUT("api/chamados/{id}")
    Call<Void> atualizarChamado(
            @Path("id") int idChamado,
            @Body ChamadosUpdate chamadoUpdate
    );

    // ======================================
    // RESPOSTAS IA
    // ======================================

    // GET /api/respostas-ia - Listar todas as respostas da IA
    @GET("api/respostas-ia")
    Call<List<RespostaIA>> listarRespostasIA();

    // GET /api/respostas-ia/chamado/{id} - Buscar respostas por ID do chamado
    @GET("api/respostas-ia/chamado/{id}")
    Call<List<RespostaIA>> buscarRespostasPorChamado(@Path("id") int idChamado);

    // ======================================
    // USUÁRIOS
    // ======================================

    // GET /api/usuarios - Listar todos os usuários
    @GET("api/usuarios")
    Call<List<Usuario>> listarTodosUsuarios();

    // ======================================
    // LISTAS DE APOIO
    // ======================================

    // GET /api/categorias - Listar todas as categorias
    @GET("api/categorias")
    Call<List<Categoria>> listarCategorias();

    // GET /api/status - Listar todos os status
    @GET("api/status")
    Call<List<Status>> listarStatus();
}