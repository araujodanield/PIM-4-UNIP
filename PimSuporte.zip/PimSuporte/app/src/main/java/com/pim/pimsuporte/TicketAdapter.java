// Local: com/pim/pimsuporte/TicketAdapter.java
package com.pim.pimsuporte;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import models.Chamado; // Importa o modelo Chamado criado

public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.TicketViewHolder> {

    private List<Chamado> listaTickets;

    public TicketAdapter(List<Chamado> listaTickets) {
        this.listaTickets = listaTickets;
    }

    // ViewHolder: Mapeia os IDs do item_ticket.xml
    public static class TicketViewHolder extends RecyclerView.ViewHolder {
        public TextView txtTituloTicket;
        public TextView txtStatusTicket;
        public TextView txtUsuarioEmissor; // Adicionei para exemplo

        public TicketViewHolder(View itemView) {
            super(itemView);

            // ATENÇÃO: Os IDs devem ser os mesmos do seu item_ticket.xml
            txtTituloTicket = itemView.findViewById(R.id.txtTituloTicket);
            txtStatusTicket = itemView.findViewById(R.id.txtStatusTicket);

        }
    }

    @NonNull
    @Override
    public TicketViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // ATENÇÃO: item_ticket deve ser o nome exato do seu arquivo XML de item.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ticket, parent, false);
        return new TicketViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TicketViewHolder holder, int position) {
        // Pega o objeto de dados da API na posição atual
        Chamado currentChamado = listaTickets.get(position);

        // APLICAÇÃO DOS DADOS DA API NAS VIEWS:

        // 1. Título do Chamado
        holder.txtTituloTicket.setText(currentChamado.getTitulo());

        // 2. Status do Chamado
        holder.txtStatusTicket.setText("Status: " + currentChamado.getStatus());


        // Você pode formatar e exibir outros campos, como:
        // holder.txtCategoria.setText("Categoria: " + currentChamado.getCategoria());
    }

    @Override
    public int getItemCount() {
        return listaTickets.size();
    }
}