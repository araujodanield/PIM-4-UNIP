﻿using System;
using System.ComponentModel.DataAnnotations;


namespace WebChamado.Models
{
    public class AbrirChamadoModel
    {
        public required string Titulo { get; set; }
        public required string Descricao { get; set; }
        public required string Categoria { get; set; }
    }
}

