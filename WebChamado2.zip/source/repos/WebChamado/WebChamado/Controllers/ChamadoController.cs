﻿using Microsoft.AspNetCore.Mvc;
using WebChamado.Models;

namespace WebChamado.Controllers
{
    public class ChamadoController : Controller
    {
        // Página com formulário de abrir chamado
        public IActionResult AbrirChamado()
        {
            return View();
        }

            [HttpPost]
            public IActionResult Abrir(AbrirChamadoModel chamado)
            {
                if (ModelState.IsValid)
                {
                    // Aqui você salva o chamado no banco ou processa
                    Console.WriteLine($"Chamado aberto: {chamado.Titulo} - {chamado.Descricao} - {chamado.Categoria}");

                    return RedirectToAction("TicketEnviado");
                }
                return View();
            }
        

        // Página de confirmação
        public IActionResult TicketEnviado()
        {
            return View(); // isso vai abrir Views/Chamado/TicketEnviado.cshtml
        }

    }
}

