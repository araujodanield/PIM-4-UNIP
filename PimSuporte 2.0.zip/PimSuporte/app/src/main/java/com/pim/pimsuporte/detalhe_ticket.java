package com.pim.pimsuporte;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pim.pimsuporte.API.API;
import com.pim.pimsuporte.API.retrofitclient;
import com.pim.pimsuporte.models.RespostaIA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class detalhe_ticket extends AppCompatActivity {

    private Button botaoNao;
    private Button botaoSim;
    private TextView txtTitulo;
    private TextView txtStatus;
    private TextView txtDescricao;

    // RecyclerView para as respostas da IA
    private RecyclerView recyclerViewRespostas;
    private RespostaIAAdapter respostaAdapter;

    // API
    private API apiService;

    // ID do ticket atual
    private int ticketId;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detalhe_ticket);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        try {
            botaoNao = findViewById(R.id.buttonNao);
            botaoSim = findViewById(R.id.buttonSim);
            txtTitulo = findViewById(R.id.txtTitulo);
            txtStatus = findViewById(R.id.txtStatus);
            txtDescricao = findViewById(R.id.txtDescricao);
            recyclerViewRespostas = findViewById(R.id.recyclerViewRespostasIA);

            if (recyclerViewRespostas == null) {
                Log.e("DETALHE_TICKET", "RecyclerView não encontrado!");
                Toast.makeText(this, "Erro ao carregar layout", Toast.LENGTH_SHORT).show();
                return;
            }

            // Configura o RecyclerView
            recyclerViewRespostas.setLayoutManager(new LinearLayoutManager(this));
            recyclerViewRespostas.setNestedScrollingEnabled(false);

        } catch (Exception e) {
            Log.e("DETALHE_TICKET", "Erro ao inicializar views: " + e.getMessage());
            e.printStackTrace();
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        // Recebe os dados enviados da tela anterior
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ticketId = extras.getInt("TICKET_ID", -1);
            String titulo = extras.getString("TICKET_TITULO", "");
            String status = extras.getString("TICKET_STATUS", "");
            String descricao = extras.getString("TICKET_DESCRICAO", "");

            // Exibe os dados na tela
            if (txtTitulo != null) {
                txtTitulo.setText(titulo);
            }
            if (txtStatus != null) {
                txtStatus.setText("Status: " + status);
            }
            if (txtDescricao != null) {
                txtDescricao.setText(descricao);
            }

            // Carrega as respostas da IA
            if (ticketId != -1) {
                carregarRespostasIA(ticketId);
            }
        }

        // Configura os botões
        if (botaoNao != null) {
            botaoNao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onNaoClick(v);
                }
            });
        }

        if (botaoSim != null) {
            botaoSim.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onSimClick(v);
                }
            });
        }
    }

    private void carregarRespostasIA(int idChamado) {
        // Tenta buscar respostas específicas do chamado
        Call<List<RespostaIA>> call = apiService.buscarRespostasPorChamado(idChamado);

        call.enqueue(new Callback<List<RespostaIA>>() {
            @Override
            public void onResponse(Call<List<RespostaIA>> call, Response<List<RespostaIA>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<RespostaIA> respostas = response.body();

                    if (respostas.isEmpty()) {
                        Toast.makeText(detalhe_ticket.this,
                                "Nenhuma solução da IA encontrada para este ticket.",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        // Configura o adapter com as respostas
                        respostaAdapter = new RespostaIAAdapter(respostas);
                        recyclerViewRespostas.setAdapter(respostaAdapter);

                        Log.d("RESPOSTAS_IA", respostas.size() + " respostas carregadas");
                    }
                } else {
                    Log.e("API_ERROR", "Erro ao carregar respostas: " + response.code());
                    // Se o endpoint específico não existir, tenta buscar todas e filtrar
                    carregarTodasRespostasIA(idChamado);
                }
            }

            @Override
            public void onFailure(Call<List<RespostaIA>> call, Throwable t) {
                Log.e("API_FAILURE", "Falha ao carregar respostas: " + t.getMessage());
                // Tenta buscar todas as respostas como fallback
                carregarTodasRespostasIA(idChamado);
            }
        });
    }

    // Método alternativo: busca todas as respostas e filtra pelo ID do chamado
    private void carregarTodasRespostasIA(int idChamado) {
        Call<List<RespostaIA>> call = apiService.listarRespostasIA();

        call.enqueue(new Callback<List<RespostaIA>>() {
            @Override
            public void onResponse(Call<List<RespostaIA>> call, Response<List<RespostaIA>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<RespostaIA> todasRespostas = response.body();

                    // Filtra apenas as respostas deste chamado
                    List<RespostaIA> respostasFiltradas = new ArrayList<>();
                    for (RespostaIA resposta : todasRespostas) {
                        if (resposta.getFkChamado() == idChamado) {
                            respostasFiltradas.add(resposta);
                        }
                    }

                    if (!respostasFiltradas.isEmpty()) {
                        respostaAdapter = new RespostaIAAdapter(respostasFiltradas);
                        recyclerViewRespostas.setAdapter(respostaAdapter);
                        Log.d("RESPOSTAS_IA", respostasFiltradas.size() + " respostas encontradas");
                    } else {
                        Toast.makeText(detalhe_ticket.this,
                                "Nenhuma solução da IA encontrada.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<List<RespostaIA>> call, Throwable t) {
                Log.e("API_FAILURE", "Erro ao carregar respostas: " + t.getMessage());
                Toast.makeText(detalhe_ticket.this,
                        "Erro ao carregar soluções da IA.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onVoltarClick(View view) {
        finish();
    }

    public void onNaoClick(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Atenção!");
        builder.setMessage("O seu problema será encaminhado a um técnico do suporte.");
        builder.setPositiveButton("Fechar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void onSimClick(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Confirmar Resolução");
        builder.setMessage("Tem certeza que o problema foi resolvido e deseja fechar o ticket?");

        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Finaliza o ticket no banco de dados
                finalizarTicket();
            }
        });

        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void finalizarTicket() {
        // Tenta primeiro o endpoint específico de finalizar
        Call<Void> call = apiService.finalizarChamado(ticketId);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // Atualiza o status na tela
                    txtStatus.setText("Status: Finalizado");

                    Toast.makeText(detalhe_ticket.this,
                            "Ticket fechado com sucesso!",
                            Toast.LENGTH_LONG).show();

                    // Desabilita os botões
                    botaoSim.setEnabled(false);
                    botaoNao.setEnabled(false);

                    // Volta para a tela anterior após 2 segundos
                    new android.os.Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    }, 2000);

                } else {
                    // Se o endpoint específico não existir, tenta o método genérico
                    Log.e("API_ERROR", "Erro ao finalizar: " + response.code());
                    finalizarTicketGenerico();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e("API_FAILURE", "Erro ao finalizar: " + t.getMessage());
                // Tenta o método alternativo
                finalizarTicketGenerico();
            }
        });
    }

    // Método alternativo para finalizar ticket usando PUT genérico
    private void finalizarTicketGenerico() {
        Map<String, Object> updates = new HashMap<>();
        updates.put("fk_status", 3); // Assumindo que 3 = Finalizado
        // OU updates.put("status", "Finalizado");

        Call<Void> call = apiService.atualizarChamado(ticketId, updates);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    txtStatus.setText("Status: Finalizado");

                    Toast.makeText(detalhe_ticket.this,
                            "Ticket fechado com sucesso!",
                            Toast.LENGTH_LONG).show();

                    botaoSim.setEnabled(false);
                    botaoNao.setEnabled(false);

                    new android.os.Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    }, 2000);
                } else {
                    Toast.makeText(detalhe_ticket.this,
                            "Erro ao finalizar ticket: " + response.code(),
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(detalhe_ticket.this,
                        "Falha ao finalizar ticket: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}