package com.pim.pimsuporte;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.DialogInterface;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class detalhe_ticket extends AppCompatActivity {

    private Button botaoNao;
    private Button botaoSim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detalhe_ticket);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        botaoNao = findViewById(R.id.buttonNao);
        botaoSim = findViewById(R.id.buttonSim);

        if (botaoNao != null) {
            botaoNao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onNaoClick(v);
                }
            });
        }

        if (botaoSim != null) {
            botaoSim.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onSimClick(v);
                }
            });
        }
    }

    public void onVoltarClick(View view) {
        finish();
    }

    public void onNaoClick(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Atenção!");
        builder.setMessage("O seu problema será encaminhado a um técnico do suporte.");
        builder.setPositiveButton("Fechar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void onSimClick(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Confirmar Resolução");
        builder.setMessage("Tem certeza que o problema foi resolvido e deseja fechar o ticket?");

        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                Toast.makeText(detalhe_ticket.this, "Ticket fechado com sucesso!", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}