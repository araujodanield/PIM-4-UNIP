package com.pim.pimsuporte;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pim.pimsuporte.models.RespostaIA;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RespostaIAAdapter extends RecyclerView.Adapter<RespostaIAAdapter.RespostaViewHolder> {

    private List<RespostaIA> listaRespostas;
    private SimpleDateFormat dateFormat;

    public RespostaIAAdapter(List<RespostaIA> listaRespostas) {
        this.listaRespostas = listaRespostas != null ? listaRespostas : new ArrayList<>();
        this.dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
    }

    public static class RespostaViewHolder extends RecyclerView.ViewHolder {
        public TextView txtResposta;
        public TextView txtDataHora;

        public RespostaViewHolder(View itemView) {
            super(itemView);
            txtResposta = itemView.findViewById(R.id.txtMensagem);
            txtDataHora = itemView.findViewById(R.id.txtDataHora);
        }
    }

    @NonNull
    @Override
    public RespostaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.mensagem_ia, parent, false);
        return new RespostaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RespostaViewHolder holder, int position) {
        RespostaIA resposta = listaRespostas.get(position);

        holder.txtResposta.setText(resposta.getResposta());

        // Formata a data
        if (resposta.getDataResposta() != null) {
            holder.txtDataHora.setText(dateFormat.format(resposta.getDataResposta()));
        } else {
            holder.txtDataHora.setText("");
        }
    }

    @Override
    public int getItemCount() {
        return listaRespostas.size();
    }

    // Método para atualizar a lista
    public void updateList(List<RespostaIA> newList) {
        this.listaRespostas = newList != null ? newList : new ArrayList<>();
        notifyDataSetChanged();
    }
}
