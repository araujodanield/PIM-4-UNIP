package models;

import java.io.Serializable;
import com.google.gson.annotations.SerializedName;

public class Status implements Serializable {

    @SerializedName("id_status")
    private int idStatus;

    @SerializedName("status")
    private String nome;

}
