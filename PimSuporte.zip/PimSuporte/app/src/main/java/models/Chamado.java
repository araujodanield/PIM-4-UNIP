package models;
import java.io.Serializable;
import java.util.Date;
import com.google.gson.annotations.SerializedName;

public class Chamado implements Serializable {

    // Identificação do Chamado
    @SerializedName("id_chamado")
    private int idChamado;

    // Chaves Estrangeiras (IDs) - Usado para referências internas
    @SerializedName("fk_usuario")
    private int fkUsuario;

    @SerializedName("fk_categoria")
    private int fkCategoria;

    @SerializedName("fk_prioridade")
    private int fkPrioridade;

    @SerializedName("fk_status")
    private int fkStatus;

    @SerializedName("fk_tecnico")
    private int fkTecnico;

    @SerializedName("fk_avaliacao")
    private int fkAvaliacao;

    // Campos de JOIN (Nomes amigáveis para exibir na UI)
    @SerializedName("usuario_emissor")
    private String usuarioEmissor;

    @SerializedName("categoria")
    private String categoria;

    @SerializedName("prioridade")
    private String prioridade;

    @SerializedName("status")
    private String status;

    @SerializedName("tecnico")
    private String tecnico; // Nome do técnico responsável

    @SerializedName("avaliacao")
    private String avaliacao;
    // Outros dados do chamado
    @SerializedName("titulo")
    private String titulo;

    @SerializedName("descricao")
    private String descricao;

    @SerializedName("resolvido_ia")
    private boolean resolvidoIA;

    // O comentário_tecnico pode ser nulo no banco. O Gson gerencia isso.
    @SerializedName("comentario_tecnico")
    private String comentarioTecnico;

    // Datas (mapeado de DateTime do C#)
    @SerializedName("data_abertura")
    private Date dataAbertura;

    @SerializedName("data_encerramento")
    private Date dataEncerramento;


    public Chamado() {
    }

    // Implemente todos os Getters (para acessar os dados)
    // E Setters (opcionais, mas boas práticas de POJO)

    public int getIdChamado() {
        return idChamado;
    }
    // ... (restante dos Getters e Setters) ...

    public String getUsuarioEmissor() {
        return usuarioEmissor;
    }

    public String getDescricao() {
        return descricao;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }


}
