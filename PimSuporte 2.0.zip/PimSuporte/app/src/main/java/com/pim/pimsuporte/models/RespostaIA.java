package com.pim.pimsuporte.models;

import java.io.Serializable;
import com.google.gson.annotations.SerializedName;

public class RespostaIA implements Serializable {

    @SerializedName("id_resposta")
    private int idResposta;

    @SerializedName("fk_chamado")
    private int fkChamado;

    @SerializedName("titulo_chamado")
    private String tituloChamado;

    @SerializedName("resposta")
    private String resposta;

    @SerializedName("data_resposta")
    private String dataResposta; // Ou Date se preferir

    // Construtor vazio
    public RespostaIA() {
    }

    // Getters
    public int getIdResposta() {
        return idResposta;
    }

    public int getFkChamado() {
        return fkChamado;
    }

    public String getTituloChamado() {
        return tituloChamado;
    }

    public String getResposta() {
        return resposta;
    }

    public String getDataResposta() {
        return dataResposta;
    }

    // Setters
    public void setIdResposta(int idResposta) {
        this.idResposta = idResposta;
    }

    public void setFkChamado(int fkChamado) {
        this.fkChamado = fkChamado;
    }

    public void setTituloChamado(String tituloChamado) {
        this.tituloChamado = tituloChamado;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public void setDataResposta(String dataResposta) {
        this.dataResposta = dataResposta;
    }
}
