using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WebChamado.Models;

namespace WebChamado.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // P�gina inicial
        public IActionResult Index()
        {
            return View();
        }

        // P�gina para visualizar informa��es gerais (ou outra funcionalidade)
        public IActionResult Visualizar()
        {
            return View();
        }

        // P�gina de erro
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}

