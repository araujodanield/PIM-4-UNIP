package API;

import models.Chamado;
import models.Categoria;
import models.Status;
import models.Usuario;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface API {

    // ======================================
    // Chamados
    // ======================================

    // GET /api/chamados
    @GET("/api/chamados")
    Call<List<models.Chamado>> listarTodosChamados();

    // GET /api/chamados/{id}
    @GET("/api/chamados/{id}")
    Call<models.Categoria> buscarChamadoPorId(@Path("id") int idChamado);

    // ======================================
    // Usuários
    // ======================================

    // GET /api/usuarios
    @GET("/api/usuarios")
    Call<List<models.Usuario>> listarTodosUsuarios();

    // ======================================
    // Listas de Apoio
    // ======================================

    // GET /api/categorias
    @GET("/api/categorias")
    Call<List<models.Categoria>> listarCategorias();


    // GET /api/status
    @GET("/api/status")
    Call<List<models.Status>> listarStatus();

}

