package com.pim.pimsuporte;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.exemplo.seuapp.R;
import models.Chamado;

import java.util.List;

public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.TicketViewHolder> {

    private List<Chamado> listaTickets;

    // Construtor: recebe a lista de tickets
    public TicketAdapter(List<Chamado> listaTickets) {
        this.listaTickets = listaTickets;
    }

    // O ViewHolder: define os componentes de cada item
    public static class TicketViewHolder extends RecyclerView.ViewHolder {
        public TextView txtTituloTicket;
        public TextView txtStatusTicket;

        public TicketViewHolder(View itemView) {
            super(itemView);
            txtTituloTicket = itemView.findViewById(R.id.txtTituloTicket);
            txtStatusTicket = itemView.findViewById(R.id.txtStatusTicket);
        }
    }

    @NonNull
    @Override
    public TicketViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Cria a view a partir do XML 'item_ticket.xml'
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ticket, parent, false);
        return new TicketViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TicketViewHolder holder, int position) {
        // Pega o objeto Chamado na posição atual
        Chamado currentChamado = listaTickets.get(position);

        // Define os dados do objeto nos componentes visuais (os campos da tela)
        holder.txtTituloTicket.setText(currentChamado.getTitulo()); // Assumindo que Chamado tem getTitulo()
        holder.txtStatusTicket.setText("Status: " + currentChamado.getStatus().getNome()); // Assumindo que Chamado tem Status, e Status tem getNome()
    }

    @Override
    public int getItemCount() {
        // Retorna o tamanho da lista (necessário para o RecyclerView saber quantos itens exibir)
        return listaTickets.size();
    }
}
