﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebChamado.Models
{
    public class AbrirChamadoModel
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "O título é obrigatório.")]
        public required string Titulo { get; set; }

        [Required(ErrorMessage = "A descrição é obrigatória.")]
        public required string Descricao { get; set; }

        [Required(ErrorMessage = "A categoria é obrigatória.")]
        public required string Categoria { get; set; }

        public DateTime DataAbertura { get; set; } = DateTime.Now;

        // Futuramente vai armazenar o status: Aberto, Em andamento, Fechado etc.
        public string Status { get; set; } = "Aberto";
    }
}
