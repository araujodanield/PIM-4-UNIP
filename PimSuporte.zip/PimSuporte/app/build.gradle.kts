plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.pim.pimsuporte"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pim.pimsuporte"
        minSdk = 21
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    //noinspection GradleDependency
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    //noinspection UseTomlInstead,GradleDependency
    implementation("com.google.android.material:material:1.12.0")
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

}